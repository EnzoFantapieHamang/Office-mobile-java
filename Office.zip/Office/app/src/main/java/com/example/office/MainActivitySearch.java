package com.example.office;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivitySearch extends AppCompatActivity {

    private EditText searchNom;
    private EditText searchRef;
    private TextView resultSearch;
    private Button buttonRecherche;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_search);

        searchNom=findViewById(R.id.et_searchNom);
        searchRef=findViewById(R.id.et_searchRef);
        resultSearch=findViewById(R.id.tv_resulteRecherche);
        buttonRecherche=findViewById(R.id.button);

        buttonRecherche.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resultSearch();
            }
        });


    }
    public void resultSearch(){
        String nom=searchNom.getText().toString();
        String ref=searchRef.getText().toString();

        resultSearch.setText("");

        if(!nom.isEmpty()) {
            for (Produit produit : Modele.catalogue) {
                if (produit.getNom().contains(nom)) {
                    resultSearch.setText(resultSearch.getText().toString() + "\n" + produit.toString());
                }
            }
        }
        else{
            for (Produit produit : Modele.catalogue) {
                if (produit.getRef().equals(ref)) {
                    resultSearch.setText(produit.toString());
                }
            }
        }

    }
}